'use strict';

module.exports = function (grunt, options) {
    return {
    };
};
