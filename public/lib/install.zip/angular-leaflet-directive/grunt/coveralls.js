'use strict';

module.exports = function (grunt, options) {
    // Options
    return {
        options: {
            debug: true,
            coverage_dir: 'coverage'
        }
    };
};
