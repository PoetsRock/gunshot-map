wget -I /static/,/doc/qt-5.0/ -k -nH --cut-dirs=2 -r http://qt-project.org/doc/qt-5.0/qtdoc/index.html
